<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Validator;

class CubeSummationController extends Controller
{
    public function input(Request $request){
    	//validamos la entrada
    	$validator = Validator::make($request->all(),[
            'file_input'          => 'required|mimes:txt',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

    	//obtenemos el campo file_input definido en el formulario
    	$file = $request->file('file_input');

    	//obtenemos la ubucacion del archivo
       	$path = $file->getRealPath();
    	
    	//abrimos el archivo
       	$_fp = fopen($path, "r");

       	$arrayInput=array();
		$output = array();


		if ($_fp) {
			$i=0;
		    while (($line = fgets($_fp)) !== false) {
		        // process the line read.
		  	
		  		$arrayInput[$i]=$line;
		  		$i=$i+1;
		    }

		    fclose($_fp);
		} else {
		    // error opening the file.
		}

		$arrayTem=array();
		$totalTest=$arrayInput[0];
		for($tem=1;$tem<count($arrayInput);$tem++){
				$arrayTem[$tem]=$arrayInput[$tem];

			}
			$arrayInput=$arrayTem;
			
			$cut=1;
			$arraylongTest=array();
			for($numTest=0;$numTest<$totalTest;$numTest++){
				 $line2=explode(" ",$arrayInput[$cut]);
				 $line2[1];
				 $cut=$line2[1]+2;
				 $arraylongTest[$numTest]=$line2[1];	
			}
			$arrTipeQuery=array();
			$index=2;
			for ($r=0;$r<count($arraylongTest);$r++) {
				
				for ($x=0;$x<$arraylongTest[$r];$x++){
					//echo $x.$arraylongTest[$r];
					$arrTipeQuery[$r][$x]=explode(" ", $arrayInput[$x+$index]);
				}
				$index=$index+$arraylongTest[$r]+1;
		}
			$arrOut=array();

			foreach ($arrTipeQuery as $k => $untipe) {
				for($ref=0;$ref<=100;$ref++){
					$arrayMatrix[$ref]=0;
				}
				
				for($i=0;$i<count($untipe);$i++){
					if($untipe[$i][0]=="UPDATE"){
					 $arrayMatrix[$untipe[$i][1]]=$untipe[$i][4];
					}
					else{
						 $base = $untipe[$i][4]-$untipe[$i][3];
						if($base==0){

							if($arrayMatrix[$base]==$arrayMatrix[$untipe[$i][3]]){
								$resul =$arrayMatrix[$base]+$arrayMatrix[$untipe[$i][4]];
							}
							else{
								$resul =$arrayMatrix[$base]+$arrayMatrix[$untipe[$i][4]];

							}
									
						}
						else{
							if($arrayMatrix[$base]==$arrayMatrix[$untipe[$i][3]]){
								$resul = $arrayMatrix[$base]+$arrayMatrix[$untipe[$i][4]];
							}
							else{

								  $resul = $arrayMatrix[$base]+$arrayMatrix[$untipe[$i][3]]+$arrayMatrix[$untipe[$i][4]];
							}
							
						}
					 array_push($output,$resul);
					}

				}

			}

			return view("file_output",compact("output"));


    }
}
